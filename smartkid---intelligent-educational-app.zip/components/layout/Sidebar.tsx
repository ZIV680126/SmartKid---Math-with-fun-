
import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { Home, User, Award, Gamepad2, LogOut, UserCircle2 } from 'lucide-react';
import { UserContext } from '../../context/UserContext';

const Sidebar: React.FC = () => {
  const userContext = useContext(UserContext);

  if (!userContext) return null;
  const { user, logout } = userContext;

  const handleLogout = () => {
    logout();
  };

  const navItems = [
    { to: '/', icon: Home, label: 'עמוד הבית' },
    { to: '/profile', icon: User, label: 'הפרופיל שלי' },
    { to: '/achievements', icon: Award, label: 'ההישגים שלי' },
    { to: '/games', icon: Gamepad2, label: 'משחקים' },
  ];

  return (
    <div className="w-64 bg-white h-full shadow-lg flex flex-col p-4 border-l-2 border-gray-100">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-black text-primary">SmartKid</h1>
        <p className="text-sm text-textSecondary">מורה פרטי חכם</p>
      </div>
      
      <div className="flex flex-col items-center mb-8">
        {user.avatarUrl ? (
          <img src={user.avatarUrl} alt="Avatar" className="w-24 h-24 rounded-full object-cover border-4 border-secondary mb-2" />
        ) : (
          <div className="w-24 h-24 rounded-full border-4 border-secondary mb-2 bg-gray-200 flex items-center justify-center">
            <UserCircle2 className="w-16 h-16 text-gray-400" />
          </div>
        )}
        <h2 className="text-xl font-bold text-textPrimary">{user.name}</h2>
        <p className="text-md text-textSecondary">כיתה {user.grade}'</p>
      </div>

      <nav className="flex-1">
        <ul>
          {navItems.map(item => (
            <li key={item.to}>
              <NavLink 
                to={item.to}
                className={({ isActive }) => `flex items-center p-3 my-2 rounded-lg text-lg transition-all duration-200 ${isActive ? 'bg-primary text-white shadow-md' : 'text-textSecondary hover:bg-gray-100 hover:text-primary'}`}
              >
                <item.icon className="w-6 h-6 mr-3" />
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="mt-auto">
        <button onClick={handleLogout} className="flex items-center p-3 w-full rounded-lg text-lg text-textSecondary hover:bg-red-100 hover:text-red-600 transition-all duration-200">
          <LogOut className="w-6 h-6 mr-3" />
          התנתקות
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
