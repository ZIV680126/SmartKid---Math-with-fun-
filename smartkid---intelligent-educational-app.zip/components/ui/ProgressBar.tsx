
import React from 'react';

interface ProgressBarProps {
  value: number; // 0 to 100
  color?: string;
  className?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value, color = 'bg-secondary', className = '' }) => {
  const progress = Math.min(Math.max(value, 0), 100);
  return (
    <div className={`w-full bg-gray-200 rounded-full h-4 overflow-hidden ${className}`}>
      <div
        className={`${color} h-4 rounded-full transition-all duration-500 ease-out`}
        style={{ width: `${progress}%` }}
      ></div>
    </div>
  );
};

export default ProgressBar;
